public class Ejercicio_Tema_3_Parte_2 {
    public static void main(String[] args) {
        Coche miCoche = new Coche();
        miCoche.SumaPuerta();

        System.out.println(miCoche.puertas);
    }
}

class Coche {
    public int puertas = 3;

    public void SumaPuerta() {
        this.puertas++;
    }
}