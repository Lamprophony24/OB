public class Ejercicio_Tema_4 {
    public static void main(String[] args){
        System.out.println("Uso del 'If'");
        int numeroIf = -8;
        if(numeroIf > 0){
            System.out.println("El número " + numeroIf + " es positivo");
        } else if (numeroIf < 0){
            System.out.println("El número " + numeroIf + " es negativo");
        } else {
            System.out.println("El número es " + numeroIf);
        }

        System.out.println("Uso del 'While'");
        int numeroWhile = -5;
        while (numeroWhile < 3){
            System.out.println(numeroWhile);
            numeroWhile++;
        }

        System.out.println("Uso del 'Do While'");
        int numeroDo = 8;
        do {
            System.out.println(numeroDo);
            numeroDo++;
        } while(false);

        System.out.println("Uso del 'For'");
        for (int numeroFor = 0; numeroFor <= 3; numeroFor++){
            System.out.println(numeroFor);
        }

        System.out.println("Uso del 'Switch'");
        var estacion = "algo";
        switch(estacion) {
            case "invierno":
                System.out.println("Es " + estacion);
                break;
            case "primavera":
                System.out.println("Es " + estacion);
                break;
            case "verano":
                System.out.println("Es " + estacion);
                break;
            case "otoño":
                System.out.println("Es " + estacion);
                break;
            default:
                System.out.println(estacion + " no es una estación");
        }

    }
}
